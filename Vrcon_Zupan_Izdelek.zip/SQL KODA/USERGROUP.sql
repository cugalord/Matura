create role Operator;
grant select, insert, update on table Member to role Operator;
grant select, insert, update on table Event to role Operator;
grant select, insert, update on table Product to role Operator;
grant select on table Staff to role Operator;
grant select on table Ptype to role Operator;