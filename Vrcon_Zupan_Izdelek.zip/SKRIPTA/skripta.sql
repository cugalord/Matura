--execute procedure purge_reservation;
select * from pp_flow;